# Let case differences develop the explanation

Use for qualitative findings, discussions or a mixed evidence set when a theme names an experience without explaining how it takes different forms. Select a scene or account that makes the proposed relationship visible, then compare a case in which a relevant action or condition works differently. Use this difference to revise the meaning, scope or proposed process of the theme. Keep actors and actions visible; a conceptual label should make the cases easier to understand.

N07 (Findings and Discussion; Tables1–3) contains awkward online help-seeking without prior ties, more accessible help with established ties, housing instability and racialised experiences despite friendships. Its authors organise belonging across educational stages; the project rejects absorbing every difficulty into one membership mechanism. N08 (Findings:Mary,Zoe,Peggy; Discussion) shows the same standard taking roles in course design, competition and doctoral study. C24 (four case narratives; Cross-Case Analysis; Table2) shows that absent administrative support can accompany peer collaboration or wider professional work, and encouragement can coexist with delayed leadership. These differences refine an explanation of action rather than rank commitment.

Preserve other supported explanations where they change the interpretation. Quote only exact source text; distinguish participant accounts, observed practice and the published author's inference. Do not manufacture within-person trajectories from cross-case or single-wave evidence.

Where the record permits, compare the same actor across settings or cases that differ in a relevant condition. A parent who organises community activities but speaks little at school cannot be adequately described by a general passivity label. Their report of unfamiliar school procedures suggests a question about conditions for speaking; it does not by itself identify the cause. Let such differences change the explanation, not merely decorate its limitations.

Exception: variation may reflect sampling or different tasks rather than a shared mechanism. Sparse cases can suggest a distinction without identifying its cause. Do not invent a missing comparison or make every counterexample fit the preferred theme.

[Same-fact example](../examples/cases-same-facts.md). Sources: [N07](../sources/N07.json), [N08](../sources/N08.json), [C24](../sources/C24.json), [N06](../sources/N06.json). Conditional project method; AI source reading, human review pending.

New source comparison (2026-10-18): E09 PDF 8–16, E10 PDF 23–26, E18 PDF 9/14–19 and E12 B048–B057. See repository `distill/20261018/cross-article.md` M5 for loci, differences and rejected inferences. This supports a candidate action, not a demonstrated writing gain.
