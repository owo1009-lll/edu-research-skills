# 修改、压缩与翻译：保留同一个判断

以下均为合成练习，不是真实研究结果；只展示操作，不作为写作效果测试。只在相应任务需要时读取。规则见 [修改原则](../foundation.md)；全文依据及不适用情形记录在仓库 `distill/20261018/cross-article.md` M2/M6/M7。

## 修改：修复越界，保留有依据的建议

**给定材料**：课程作业已要求答案和理由，部分学生的理由只是复述答案。作者将 answerability 界定为能为判断给出理由并回应追问；作者坚持课程应保护学生回应追问的机会。没有比较追问活动的效果。

**原稿**

> Requiring reasons has made students answerable for their judgments. Courses should protect opportunities to respond to questions about those reasons.

**修改**

> Requiring reasons has not ensured that they can be examined: some students merely restated their answers. If answerability includes giving reasons and responding to questions about them, courses should protect opportunities for that response. Whether such opportunities improve learning remains an empirical question.

第一句修复“提出要求便已实现目标”的越界。保留作者对机会的 should，写清教育前提；没有将行动效果写成已证实，也未把 answerability 换成 confidence。

## 压缩：删重复功能，留关键关系

**给定原文**

> We use answerability to mean giving reasons for a judgment and responding to questions about those reasons. Answerability therefore involves more than the speed of answering. Students answered more quickly after the activity. Yet they still had difficulty with a new task presented without prompts. Faster answers and difficulty on the unprompted task concern different aspects of performance. Neither observation directly assessed students' ability to give and defend reasons. The course should protect opportunities to respond to questions about one's reasons, because this is part of its stated educational aim.

**压缩后**

> Students answered faster after the activity but still struggled with an unprompted new task. Neither observation directly assessed answerability: giving reasons for judgments and responding to questions about them. As part of this stated educational aim, the course should protect opportunities for such responses.

合并重复的概念解释，保留速度、无提示新任务、未直接测量及规范判断。没有把“活动后”变成“活动造成”，也没有把新任务困难概括为“学习无效”。实际稿件如有主次结局与区间，还需保留会改变判断的部分。

## 翻译：改句式，不换概念或力度

上述压缩稿可译为：

> 活动后，学生回答得更快，却仍难以完成无提示的新任务。这两项观察都未直接考察其判断的“可追问性”，即能否给出理由并回应追问。既然课程已将此作为教育目标，就应保障学生回应这类追问的机会。

“可追问性”在本例是作者给定概念，实际任务须核对原稿或领域译法；不是所有 answerability 的通用译名。“应”承接目标前提，没有擅自改为“可以考虑”，也没有增强为已证明有效的措施。

## 段落推进：让行动关系取代逐句重启

**给定事实**：两个部门索取相同学生信息，格式不同；学校没有合并，教师分别填写两份表。

- 逐句重启：两个部门需要相同学生信息。两个表的格式不同。此外，教师分别填写两份。学校没有合并表格，产生了重复工作。
- 接续行动：两个部门索取相同的学生信息，却使用不同格式。学校未合并这两项要求，教师因而需要把同一信息分别填入两份表格。

后一版保持部门要求这一对象，说明格式与任务安排如何连到重复填写；未扩展为全国负担的根源。没有过程资料时不补出这一链条。
