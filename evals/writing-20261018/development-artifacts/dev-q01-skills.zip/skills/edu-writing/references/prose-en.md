# How English SSCI articles are written: paragraphs and sentences

Figures come from 50 empirical articles published 2024–2026 (repository `distill/results/writing_moves_en.md`): 22 quantitative, 15 qualitative and 13 mixed-methods.
- **Top tier (35 articles):** from journals such as AERJ, Journal of Educational Psychology, Contemporary Educational Psychology, Learning and Instruction, Computers & Education, Educational Researcher, Sociology of Education, AERA Open, Journal of Teacher Education, Teaching and Teacher Education, JRST, Science Education, BERJ, Higher Education, Studies in Higher Education, BJET, JLS, Psychology of Music and the British Journal of Music Education.
- **Other 15 articles:** from Computers & Education, BJET, ETR&D, IJETHE, Education and Information Technologies, TATE, IJME and Music Education Research.

Figures are medians unless stated. They describe how published papers usually write and are optional references, not quality targets. Whether to use a given form depends on the argument, the type of study and the target journal. How the argument is organised is in [argument](argument.md).

[voice-en](voice-en.md) covers stance: where to state and where to hedge. This file covers how paragraphs move, how literature is used and how sentences are built. Read both.

## 1. Each paragraph completes its own argument

- A paragraph advances a specific claim. Its next sentence should develop an action, condition, reason or consequence the reader still needs, keeping the object of attention traceable. A claim, scene, example or unresolved comparison can open it; the order follows the argument. Keep a necessary inferential link explicit without inventing missing processes. See [foundation](foundation.md) §6.
- **Paragraphs end on substance.** Generic value sentences ("…highlights the importance of…", "…provides valuable insights…", "…plays a crucial role…", "more research is needed") end:
  - 1.8% of Introduction paragraphs;
  - 1.3% of review paragraphs;
  - 3% of Discussion paragraphs;
  - 6% of implication paragraphs.

  They are more common in conclusions (26% of paragraphs); 13 of 50 papers close with an evaluation. These are observations, not a permitted quota. State a concrete contribution where it serves the argument.
- Paragraphs run about 140 words (published range 83–228). These lengths are descriptive references; split or combine paragraphs according to the argument, article structure and explicit journal requirements.

## 2. Using the literature

- **Claim first, citation at the end of the clause.** Write "[claim] ([Author], [year]; [Author], [year])".
  - About 57% of Introduction sentences and 60% of review sentences carry a citation: about 23 citations per 1,000 words in both.
  - An Introduction is not uncited background.
- **Few "Author (year) found" sentences, depending on design.** Narrative citations are 0% of Introduction citations and 14% of review citations (qualitative 24%).
  - **In the Discussion:** quantitative papers almost never use them (median 2.5%); qualitative papers use them for about a third (33%), mixed-methods papers for about a sixth (16%).
  - **When to name the author:** keep narrative citations for studies whose design is itself the evidence, such as one experiment, a meta-analysis or a contrary result.
  - **In a quantitative Discussion, compare information-prominently:** "This is consistent with earlier studies of [population] (A, year; B, year)", not a string of "A (year) found …; B (year) showed …".
- **Make studies answer a shared question.** Compare the claim, population, operation, measure and time point; explain what their relationship adds to understanding. A synthesis followed by a key study is one option, and a consequential disagreement is another. In the corpus, synthesis sentences outnumber single-study sentences about 2:1 (63% synthesis); repeated listing occurs in 16/50 reviews. These proportions prescribe neither sentence order nor citation counts. A study-by-study guide can be appropriate when that is the task. See [synthesis](synthesis.md).
- **Tense.** Established claims with a parenthetical citation take the present or present perfect (about 90%). The verb after "Author (year)" is past in 60% of cases; *found* is the most common.
- **Bundles.** Put three or more works in one parenthesis for consensus claims only (about one parenthesis in ten in reviews, one in six in Introductions).
- **Counter-evidence.** Quantitative reviews almost always give contrary or mixed evidence (21/22); qualitative (8/15) and mixed-methods (7/13) reviews do so where the literature is contested. Devices:
  - "findings on [X] are mixed: [A] reported …, whereas [B] …";
  - "although [consensus] (cites), [study] found [exception]";
  - "However, [Author] ([year]) showed …".
- **Gap.** Focus on the key unresolved matters needed to motivate the research questions: a specific absence or contrast, a design weakness or a practical problem. Published papers make a median of 4 gap statements, and 30 of 49 restate the gap at the end of the review. These are observations, not requirements for the number or placement of gaps. Optional examples:
  - "Most studies have [examined A in B]; [C] remains [unexamined]."
  - "Prior studies relied on [design or measure], which cannot [show X]."

  Explain how the unresolved matters motivate the research questions; a one-to-one pairing is not required. See [introduction](introduction.md) for organising questions, hypotheses and contributions without fixed closing formulas.
- **Use only verified sources.** Use only references that have been verified (see [reference verification](reference-verification.md)). When the materials give few references, cite them where they support a claim and bundle them where several support the same claim; never invent citations to reach a density. A thin reference list is an author to-do item.
- **Each citation carries its claim.** Cite a work only for what it reports or argues, as far as its abstract or the materials show.
  - Do not attach a real source to a background claim it does not make, for example a study of consequences cited for how common a practice is.
  - Do not cite a work that does no work in the argument.
  - Use a study as support only when its finding points the way you argue; a reverse or reciprocal effect is not evidence for the forward one.
  - The published densities come from papers with 50–80 references. With a small reference pack, a lower density is correct. Stretching citations to reach the median is a more serious fault than citing too little.
  - **Problem entries in a reference pack.** Put each one on the author to-do list. They differ in what you may cite:
    - **Abstract belongs to another paper, or title only:** in new writing, do not use the work to support a new factual claim; list it for checking. In a revision, keep the author's existing citation, record it as unverified in `rationale.md`, and do not mark it as verified.
    - **Author list cut short, or online year differs from issue year:** the abstract is still usable, so cite its findings normally. In the reference list, keep the given authors followed by "[remaining authors to be added]", use the year the pack gives, and flag the discrepancy.
- **Introduction and review.** Allocate material by its role in the argument and avoid repeating the same explanation. Definitions and examples needed to understand the problem can appear in the Introduction; arrange detailed evidence according to the article structure.

## 3. Where the numbers go

- **Results.** See §7 for the design-specific openings.
  - Statistics follow the claim, in parentheses or set off by commas.
  - A quantitative Results sentence with numbers carries a median of 2.
  - About 3% of quantitative Results paragraphs open with a number.
- **Discussion and conclusion.** Restate what the evidence means and retain estimates, intervals or denominators when they determine the interpretation; avoid repeating whole result tables. In the corpus, 98% of Discussion points restate the finding, 9% with a statistic, and about 3% of Discussion sentences contain a number. These are descriptive, not limits on necessary evidence.

## 4. What stays out of the paper

- **Proposed analyses.** Sentences like "this could be tested with the present data" are notes, not prose. Either run the analysis and report it, or move the test to future research.
- **Roadmaps and cross-references.** Keep them when they help readers track a long argument or locate necessary evidence; remove directions that merely repeat a heading. In the corpus, 32/50 articles have no signposting and 7 give a short introduction roadmap. Neither frequency establishes a ban elsewhere.
- **Writing notes.** Missing sources, items to verify and term choices go to `rationale.md` and the author to-do list.

## 5. Sentences

- **Length** (reference). The published median is 27 words (22–33), with 15% over 40; Results sentences are shortest (22) and Introduction sentences longest (30.5). Do not target these figures. Split where distinct judgments burden comprehension, while keeping their logical relation and necessary conditions visible; combine short sentences when they merely restart the same object.
- **First person.** Use *we* for the study's actions and decisions: 4.8 per 1,000 words. It is most frequent in the present-study section (9.5), limitations (9.3) and Discussion (6.1); review prose rarely uses it (1.2). Impersonal prose is also within range (8 of 50 articles stay below 1 per 1,000).
- **Passive.** About a quarter of sentences use the passive (24%, range 10–46%). The measure counts *was related to* and *was associated with*, which survey designs need (see voice-en). A high figure in a short abstract is therefore normal. Across the argued sections, change passives that hide who acted (*it was decided*, *data were collected by us*), not the relational verbs.
- **Connectives.** *However* is the main contrast word (about 14 per 10,000 words); additive connectives together run at about 13 per 10,000. About one paragraph in six opens with a connective. Use a connective for the actual relation between claims; changing the word cannot repair an absent comparison or inferential step. Frequency and consecutive placement alone are not faults.
- **AI-typical words.** These words already occur in published papers, but thinly:

  | Words | Published | Use |
  |---|---|---|
  | *delve*, *in today's*, *pave the way*, *a growing body of*, *it is worth noting*, *noteworthy*, *realm*, *paramount*, *in conclusion* | 0–3 occurrences per paper in total | Check whether the phrase adds a specific meaning or merely delays the claim |
  | *crucial*, *highlight*, *foster*, *essential*, *insights*, *notably*, *underscore*, *pivotal*, *nuanced*, *multifaceted*, *leverage*, *navigate*, *robust*, *comprehensive*, *shed light on*, *play a crucial role* | median about 18 per 10,000 words for the whole set | Replace unsupported evaluation with its concrete reason; retain the word when its meaning is warranted |

  These lists describe the old corpus and checker cues, not forbidden vocabulary or per-paper targets.

- **Abbreviations.** Abbreviate only recurring core constructs and define each once (10 abbreviation tokens per 1,000 words). When a core construct's established name is itself an abbreviation (*GenAI*), keep it per the term table even if the density rises. Cut the other abbreviations instead, such as model labels like TS, SE and EN in prose.

## 6. Headings and lists

- **Discussion.** Discussion subheadings are absent in 23 of 50 articles, topic labels in 21 ("Teacher support and engagement") and claim headings in 4. Choose by the target journal and what the argument needs.
- **Implications and limitations.** Choose prose, headings or numbering for the argument and journal requirements; preserve a functioning author structure. Only 4/50 papers number implications, while 12/22 quantitative papers number limitations. Neither observation prescribes a format.

## 7. By design

The question and hypothesis formats below describe the sampled articles. Their placement and whether to number them depend on the argument, article structure and explicit journal requirements, including for qualitative and mixed-methods studies.

| | Quantitative (22) | Qualitative (15) | Mixed methods (13) |
|---|---|---|---|
| Questions and hypotheses | Hypotheses observed in 19/22, derived from theory plus evidence and usually stated in a present-study section; first-person aim (17/21) | Numbered RQs observed in 11/15; questions at the end of the Introduction in 13/15; no hypotheses in this sample; a present-study section in 2/15 | Numbered RQs observed in 10/13; a present-study section in 9/13 |
| Review | Counter-evidence almost always (21/22) | Narrative citations up to about a quarter; still synthesise rather than list | As quantitative, with counter-evidence where the literature is contested |
| Results paragraphs | Open with the procedure, the finding in words, a table pointer or a check (procedure 32%, finding 27%); 56% of sentences carry numbers | Open with a theme claim (62%), then quotes with participant codes (21% open with a quote); numbers in about 12% of sentences | The sampled papers combine theme-led and procedure- or finding-led paragraphs; numbers occur in about 42% of sentences. These are observations, not an alternating-paragraph format. Explain how the evidence connects; see [mixed-methods integration](mixed-methods.md). |
| Discussion | About half the points deal with null or contrary results; compare information-prominently | Narrative citations about a third; points may end on an implication (41% contain one) | Implications inside about a fifth of points |
| Limitations and conclusion | Median 5 limitations in the sample; numbering was common | Median 2 limitations; all 15 sampled papers included a conclusion | Follow the actual design and article structure, not the quantitative sample's counts |

## 8. Check

After drafting, you can run `python <this skill>/scripts/check_prose.py --draft <manuscript>`. It detects English and reports, section by section, the measures above against the published medians. The output gives cues for a human to judge: being outside the range does not mean poor writing, and being near the median does not mean good writing. It reports:
- citation density, cited sentences, narrative and bundled citations;
- numbers in the Discussion and Results;
- sentence and paragraph length, *we*, passive voice and abbreviations;
- connectives, paragraph-final value sentences, signposting and AI-typical words.

A draft that states hypotheses is treated as quantitative for the Discussion's narrative citations.

Cues appear only beyond the published extremes.
